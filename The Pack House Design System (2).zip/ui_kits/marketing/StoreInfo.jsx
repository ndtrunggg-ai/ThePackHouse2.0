function StoreInfo() {
  const points = [
    { num: "01", title: "Authentic, every time",
      blurb: "Every piece is sourced direct from the brand or their authorised regional distributor. Receipts and warranty cards included." },
    { num: "02", title: "Try before you fly",
      blurb: "Visit our Hàng Bè showroom to lift, strap on, and stress-test every bag. No pressure — we'd rather you take the right one." },
    { num: "03", title: "After-care in Hanoi",
      blurb: "Zipper repairs, strap replacements, warranty claims — handled in-store. Our team has factory training on Thule and Samsonite repairs." },
  ];
  return (
    <section className="tph-section tph-section-store">
      <div className="tph-section-head">
        <span className="tph-section-num">03</span>
        <h2 className="tph-section-title">Why buy from The Pack House</h2>
        <a className="tph-section-link">About us →</a>
      </div>
      <div className="tph-store-grid">
        {points.map((p) => (
          <article key={p.num} className="tph-store-point">
            <div className="tph-store-num">— No. {p.num}</div>
            <h3 className="tph-store-title">{p.title}</h3>
            <p className="tph-store-blurb">{p.blurb}</p>
          </article>
        ))}
      </div>
      <div className="tph-visit">
        <div className="tph-visit-info">
          <span className="tph-eyebrow">VISIT THE SHOP</span>
          <h3 className="tph-visit-addr">14 Hàng Bè, Hoàn Kiếm<br/>Hà Nội, Việt Nam</h3>
          <p className="tph-visit-hours">Open 10:00–19:00, daily · +84 24 6688 0410</p>
        </div>
        <div className="tph-visit-map" aria-hidden="true">
          <svg viewBox="0 0 200 120" preserveAspectRatio="xMidYMid slice">
            <rect width="200" height="120" fill="#F0E6D2"/>
            <path d="M0,40 L80,40 L80,0 M80,40 L80,120 M0,80 L200,80 M120,0 L120,120 M160,40 L200,40"
                  fill="none" stroke="#B09060" strokeWidth="0.6" opacity="0.5"/>
            <path d="M30,90 Q60,70 100,60 Q140,50 170,30"
                  fill="none" stroke="#C8A97A" strokeWidth="1.5" strokeDasharray="3 3"/>
            <circle cx="100" cy="60" r="5" fill="#2A1F0E"/>
            <circle cx="100" cy="60" r="2" fill="#C8A97A"/>
            <text x="108" y="58" fontFamily="Inter, sans-serif" fontSize="6" letterSpacing="2"
                  fill="#2A1F0E">THE PACK HOUSE</text>
          </svg>
        </div>
      </div>
    </section>
  );
}

window.StoreInfo = StoreInfo;
