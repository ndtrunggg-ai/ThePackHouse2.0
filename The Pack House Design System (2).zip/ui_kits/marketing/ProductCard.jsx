// Brand-aware product card. Each brand gets its own visual treatment.
const fmt = (n) => n.toLocaleString("vi-VN") + " ₫";

function ProductCard({ p, onAdd }) {
  const cls = "tph-card tph-card-" + p.brand;
  return (
    <article className={cls}>
      <div className="tph-card-img">
        {p.brand === "thule" && (
          <>
            <span className="tph-card-brand">THULE</span>
            <span className="tph-card-flag">SWEDEN · 1942</span>
            <div className="tph-card-mountains">
              <svg viewBox="0 0 300 100" preserveAspectRatio="xMidYMax slice">
                <polygon points="0,100 60,42 110,78 160,28 220,68 270,46 300,72 300,100" fill="#DDE0D5" opacity="0.4"/>
                <polygon points="0,100 40,62 95,85 150,52 210,82 260,66 300,82 300,100" fill="#DDE0D5" opacity="0.55"/>
              </svg>
            </div>
          </>
        )}
        {p.brand === "samsonite" && (
          <>
            <span className="tph-card-brand sam-brand-text">Samsonite</span>
            <span className="tph-card-yr">EST. 1910</span>
          </>
        )}
        {p.brand === "case-logic" && (
          <span className="tph-card-brand cl-brand-text">CASE LOGIC</span>
        )}
        {p.brand === "pacsafe" && (
          <>
            <div className="tph-card-grid-bg" />
            <span className="tph-card-brand pac-brand-text">PACSAFE</span>
            <span className="tph-card-cert">Anti-theft</span>
          </>
        )}
        {p.brand === "tumi" && (
          <span className="tph-card-brand tumi-brand-text">TUMI</span>
        )}
        {p.badge && <span className={"tph-card-badge tph-badge-" + p.badge.kind}>{p.badge.label}</span>}

        <div className="tph-card-silhouette" dangerouslySetInnerHTML={{ __html: p.svg }} />
      </div>
      <div className="tph-card-body">
        <div className="tph-card-brandline">{p.brandName}</div>
        <h4 className="tph-card-name">{p.name}</h4>
        <div className="tph-card-meta">{p.specs.join(" · ")}</div>
        <div className="tph-card-foot">
          <span className="tph-card-price">{fmt(p.price)}</span>
          <button className="tph-card-add" onClick={() => onAdd(p)} aria-label={`Add ${p.name} to cart`}>
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}

window.ProductCard = ProductCard;
window.fmt = fmt;
