function CartDrawer({ open, items, onClose, onRemove }) {
  const total = items.reduce((s, i) => s + i.price, 0);
  const fmt = (n) => n.toLocaleString("vi-VN") + " ₫";

  return (
    <>
      <div className={"tph-scrim" + (open ? " on" : "")} onClick={onClose} />
      <aside className={"tph-drawer" + (open ? " on" : "")} aria-hidden={!open}>
        <header className="tph-drawer-head">
          <span className="tph-eyebrow">YOUR CART</span>
          <button className="tph-icon-btn" onClick={onClose} aria-label="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
              <line x1="6" y1="6" x2="18" y2="18" /><line x1="18" y1="6" x2="6" y2="18" />
            </svg>
          </button>
        </header>

        <div className="tph-drawer-body">
          {items.length === 0 && (
            <div className="tph-drawer-empty">
              <div className="tph-drawer-empty-mark">∅</div>
              <p>Your cart is unpacked.</p>
              <small>Find something to carry.</small>
            </div>
          )}
          {items.map((it, i) => (
            <div key={i} className="tph-cart-line">
              <div className="tph-cart-thumb" style={{ background: it.swatch || "linear-gradient(180deg,#C8A97A,#8A7030)" }} />
              <div className="tph-cart-info">
                <div className="tph-cart-name">{it.name}</div>
                <div className="tph-cart-meta">{it.color}</div>
                <button className="tph-cart-rm" onClick={() => onRemove(i)}>Remove</button>
              </div>
              <div className="tph-cart-price">{fmt(it.price)}</div>
            </div>
          ))}
        </div>

        <footer className="tph-drawer-foot">
          <div className="tph-cart-sub">
            <span>Subtotal</span>
            <span className="tph-cart-sub-val">{fmt(total)}</span>
          </div>
          <p className="tph-cart-note">Shipping &amp; taxes calculated at checkout.</p>
          <button className="tph-btn tph-btn-primary tph-btn-block" disabled={items.length === 0}>
            Checkout
          </button>
        </footer>
      </aside>
    </>
  );
}

window.CartDrawer = CartDrawer;
