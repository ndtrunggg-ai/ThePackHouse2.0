function Footer() {
  return (
    <footer className="tph-footer">
      <div className="tph-footer-top">
        <div className="tph-footer-mark">
          <div>
            <div className="tph-footer-wm">The Pack House</div>
            <div className="tph-footer-tag">CARRY YOUR HOME · ANYWHERE</div>
            <p className="tph-footer-mini">Hanoi's curated home for trusted travel brands.<br/>Since MMXXV.</p>
          </div>
        </div>
        <div className="tph-footer-cols">
          <div>
            <div className="tph-footer-h">Shop</div>
            <a>Backpacks</a><a>Luggage</a><a>Daypacks</a><a>Laptop bags</a><a>Accessories</a>
          </div>
          <div>
            <div className="tph-footer-h">Brands</div>
            <a>Thule</a><a>Samsonite</a><a>Case Logic</a><a>Pacsafe</a><a>Tumi</a>
          </div>
          <div>
            <div className="tph-footer-h">Help</div>
            <a>Shipping &amp; returns</a><a>Warranty &amp; repairs</a><a>Size & fit guide</a><a>Order tracking</a><a>Contact us</a>
          </div>
          <div>
            <div className="tph-footer-h">Visit</div>
            <a>14 Hàng Bè, Hoàn Kiếm</a><a>Hà Nội, Việt Nam</a><a>Open 10–19 daily</a><a>+84 24 6688 0410</a><a>hello@thepackhouse.vn</a>
          </div>
        </div>
      </div>
      <div className="tph-footer-bottom">
        <span>© MMXXV The Pack House Co., Hà Nội · Authorised retailer</span>
        <span>Privacy · Terms · Shipping &amp; returns</span>
      </div>
    </footer>
  );
}

window.Footer = Footer;
