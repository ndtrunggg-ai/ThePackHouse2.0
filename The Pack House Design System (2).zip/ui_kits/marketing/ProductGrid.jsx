const PRODUCTS = [
  {
    id: "thule-subterra-2",
    brand: "thule", brandName: "Thule",
    name: "Subterra 2 Travel Pack 30 L",
    type: "backpacks",
    price: 5890000,
    specs: ["30 L", "1.4 kg", "Recycled fabric"],
    badge: null,
    featured: true, newest: 5,
    svg: `<svg viewBox="0 0 100 130" fill="none" stroke="#F5F4EE" stroke-width="1.5"><rect x="22" y="20" width="56" height="100" rx="6"/><path d="M34,20 Q34,8 50,8 Q66,8 66,20"/><line x1="22" y1="48" x2="78" y2="48"/><rect x="42" y="58" width="16" height="38" rx="1"/><circle cx="28" cy="28" r="1.5" fill="#F5F4EE"/><circle cx="72" cy="28" r="1.5" fill="#F5F4EE"/></svg>`,
  },
  {
    id: "thule-aspect-dslr",
    brand: "thule", brandName: "Thule",
    name: "Aspect DSLR Camera Backpack",
    type: "backpacks",
    price: 4200000,
    specs: ["DSLR + lenses", "Padded", "Tripod loop"],
    badge: { kind: "new", label: "New" },
    featured: true, newest: 1,
    svg: `<svg viewBox="0 0 100 130" fill="none" stroke="#F5F4EE" stroke-width="1.5"><rect x="22" y="22" width="56" height="98" rx="5"/><path d="M34,22 Q34,12 50,12 Q66,12 66,22"/><rect x="32" y="38" width="36" height="44" rx="2"/><circle cx="50" cy="60" r="9"/><line x1="22" y1="92" x2="78" y2="92"/></svg>`,
  },
  {
    id: "thule-crossover-2",
    brand: "thule", brandName: "Thule",
    name: "Crossover 2 Carry-On Spinner",
    type: "luggage",
    price: 8900000,
    specs: ["38 L", "4-wheel", "Compression panel"],
    badge: null,
    featured: false, newest: 3,
    svg: `<svg viewBox="0 0 100 130" fill="none" stroke="#F5F4EE" stroke-width="1.5"><rect x="18" y="32" width="64" height="76" rx="4"/><line x1="18" y1="64" x2="82" y2="64"/><path d="M38,32 L38,18 L62,18 L62,32"/><circle cx="28" cy="116" r="4"/><circle cx="72" cy="116" r="4"/></svg>`,
  },
  {
    id: "case-logic-era-15",
    brand: "case-logic", brandName: "Case Logic",
    name: 'Era 15.6" Laptop Sleeve',
    type: "laptop-bags",
    price: 1290000,
    specs: ["Padded", "Charcoal", "3 colours"],
    badge: { kind: "new", label: "New" },
    featured: false, newest: 2,
    svg: `<svg viewBox="0 0 100 70" fill="none" stroke="#2A1F0E" stroke-width="1.5"><rect x="10" y="16" width="80" height="42" rx="2"/><line x1="10" y1="52" x2="90" y2="52"/><rect x="38" y="10" width="24" height="6" rx="1"/><circle cx="50" cy="36" r="2" fill="#2A1F0E"/></svg>`,
  },
  {
    id: "case-logic-reflexion",
    brand: "case-logic", brandName: "Case Logic",
    name: 'Reflexion 10.5" Tablet Folio',
    type: "accessories",
    price: 590000,
    specs: ["Magnetic close", "Stand mode", "Slim"],
    badge: null,
    featured: false, newest: 4,
    svg: `<svg viewBox="0 0 100 100" fill="none" stroke="#2A1F0E" stroke-width="1.5"><rect x="24" y="14" width="52" height="72" rx="3"/><line x1="24" y1="78" x2="76" y2="78"/><rect x="44" y="38" width="12" height="22" rx="1"/></svg>`,
  },
  {
    id: "case-logic-quantic",
    brand: "case-logic", brandName: "Case Logic",
    name: "Quantic Cable Organizer",
    type: "accessories",
    price: 290000,
    specs: ["8 pockets", "Zip top", "Travel-ready"],
    badge: null,
    featured: false, newest: 6,
    svg: `<svg viewBox="0 0 100 80" fill="none" stroke="#2A1F0E" stroke-width="1.5"><rect x="14" y="22" width="72" height="42" rx="3"/><line x1="14" y1="44" x2="86" y2="44"/><line x1="32" y1="22" x2="32" y2="64"/><line x1="50" y1="22" x2="50" y2="64"/><line x1="68" y1="22" x2="68" y2="64"/></svg>`,
  },
  {
    id: "samsonite-litebox-alu",
    brand: "samsonite", brandName: "Samsonite",
    name: "Lite-Box ALU Carry-On 36 L",
    type: "luggage",
    price: 12500000,
    specs: ["Aluminium", "36 L", "Lifetime warranty"],
    badge: null,
    featured: true, newest: 7,
    svg: `<svg viewBox="0 0 100 100" fill="none" stroke="#C8A97A" stroke-width="1.5"><rect x="20" y="22" width="60" height="64" rx="4"/><line x1="20" y1="46" x2="80" y2="46"/><path d="M40,22 L40,12 L60,12 L60,22"/><circle cx="50" cy="58" r="3" fill="#C8A97A"/><line x1="32" y1="78" x2="68" y2="78" stroke-width="0.75"/></svg>`,
  },
  {
    id: "samsonite-respark",
    brand: "samsonite", brandName: "Samsonite",
    name: "Respark Spinner 67 cm",
    type: "luggage",
    price: 7800000,
    specs: ["Polypropylene", "75 L", "Expandable"],
    badge: { kind: "low", label: "3 left" },
    featured: false, newest: 8,
    svg: `<svg viewBox="0 0 100 100" fill="none" stroke="#C8A97A" stroke-width="1.5"><rect x="16" y="18" width="68" height="72" rx="6"/><line x1="16" y1="50" x2="84" y2="50"/><path d="M42,18 L42,8 L58,8 L58,18"/><circle cx="26" cy="96" r="3"/><circle cx="74" cy="96" r="3"/></svg>`,
  },
  {
    id: "pacsafe-vibe-20",
    brand: "pacsafe", brandName: "Pacsafe",
    name: "Vibe 20 Anti-theft Daypack",
    type: "daypacks",
    price: 2290000,
    specs: ["20 L", "RFID-blocking", "Slate"],
    badge: { kind: "low", label: "3 left" },
    featured: false, newest: 9,
    svg: `<svg viewBox="0 0 100 120" fill="none" stroke="#FBF7EF" stroke-width="1.5"><path d="M28,28 Q28,14 50,14 Q72,14 72,28"/><rect x="22" y="28" width="56" height="80" rx="6"/><line x1="22" y1="56" x2="78" y2="56"/><rect x="36" y="68" width="28" height="22" rx="1"/><circle cx="50" cy="46" r="3"/></svg>`,
  },
  {
    id: "pacsafe-go-25",
    brand: "pacsafe", brandName: "Pacsafe",
    name: "Go 25 L Anti-theft Backpack",
    type: "backpacks",
    price: 3590000,
    specs: ["25 L", "Cut-proof straps", "Lockable zip"],
    badge: null,
    featured: false, newest: 10,
    svg: `<svg viewBox="0 0 100 120" fill="none" stroke="#FBF7EF" stroke-width="1.5"><path d="M26,26 Q26,12 50,12 Q74,12 74,26"/><rect x="20" y="26" width="60" height="84" rx="6"/><line x1="20" y1="56" x2="80" y2="56"/><rect x="38" y="68" width="24" height="28" rx="2"/></svg>`,
  },
  {
    id: "tumi-alpha-bravo",
    brand: "tumi", brandName: "Tumi",
    name: "Alpha Bravo Search Backpack",
    type: "backpacks",
    price: 14500000,
    specs: ["Ballistic nylon", "Padded laptop", "Lifetime warranty"],
    badge: null,
    featured: true, newest: 11,
    svg: `<svg viewBox="0 0 100 130" fill="none" stroke="#E8DCC8" stroke-width="1.5"><rect x="22" y="22" width="56" height="98" rx="6"/><path d="M32,22 Q32,10 50,10 Q68,10 68,22"/><line x1="22" y1="54" x2="78" y2="54"/><rect x="34" y="64" width="32" height="36" rx="2"/></svg>`,
  },
  {
    id: "tumi-voyageur-celina",
    brand: "tumi", brandName: "Tumi",
    name: "Voyageur Celina Backpack",
    type: "daypacks",
    price: 9800000,
    specs: ["18 L", "Water-resistant", "Magnetic clasp"],
    badge: null,
    featured: false, newest: 12,
    svg: `<svg viewBox="0 0 100 120" fill="none" stroke="#E8DCC8" stroke-width="1.5"><path d="M30,28 Q30,14 50,14 Q70,14 70,28"/><rect x="24" y="28" width="52" height="80" rx="6"/><line x1="24" y1="54" x2="76" y2="54"/><rect x="38" y="68" width="24" height="24" rx="2"/></svg>`,
  },
];

function ProductGrid({ brand, type, search, sort, onAdd, onClearFilters }) {
  let list = PRODUCTS.filter((p) => {
    if (brand !== "all" && p.brand !== brand) return false;
    if (type !== "all" && p.type !== type) return false;
    if (search && search.trim()) {
      const q = search.toLowerCase();
      const hay = (p.name + " " + p.brandName + " " + p.specs.join(" ")).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  if (sort === "price-asc")  list = [...list].sort((a, b) => a.price - b.price);
  if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
  if (sort === "newest")     list = [...list].sort((a, b) => a.newest - b.newest);
  if (sort === "featured")   list = [...list].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));

  if (list.length === 0) {
    return (
      <div className="tph-empty">
        <div className="tph-empty-mark">∅</div>
        <h3>Nothing matches that yet.</h3>
        <p>Try a different brand or product type — or clear all filters to see the whole shelf.</p>
        <button className="tph-btn tph-btn-secondary" onClick={onClearFilters}>Clear filters</button>
      </div>
    );
  }

  return (
    <div className="tph-grid">
      {list.map((p) => <ProductCard key={p.id} p={p} onAdd={onAdd} />)}
    </div>
  );
}

window.PRODUCTS = PRODUCTS;
window.ProductGrid = ProductGrid;
