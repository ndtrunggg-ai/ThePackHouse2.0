const TYPES = [
  { id: "all",         name: "All products" },
  { id: "backpacks",   name: "Backpacks" },
  { id: "luggage",     name: "Luggage" },
  { id: "daypacks",    name: "Daypacks" },
  { id: "laptop-bags", name: "Laptop bags" },
  { id: "accessories", name: "Accessories" },
];

function TypeFilters({ selected, onSelect, resultCount, sort, onSort }) {
  return (
    <div className="tph-filter-bar">
      <div className="tph-chips" role="tablist" aria-label="Filter by product type">
        {TYPES.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={selected === t.id}
            className={"tph-chip" + (selected === t.id ? " on" : "")}
            onClick={() => onSelect(t.id)}
          >
            {t.name}
          </button>
        ))}
      </div>
      <div className="tph-filter-right">
        <span className="tph-result-count">{resultCount} {resultCount === 1 ? "piece" : "pieces"}</span>
        <label className="tph-sort">
          <span className="tph-sort-lbl">Sort</span>
          <select value={sort} onChange={(e) => onSort(e.target.value)} aria-label="Sort products">
            <option value="featured">Featured</option>
            <option value="price-asc">Price · low to high</option>
            <option value="price-desc">Price · high to low</option>
            <option value="newest">Newest in store</option>
          </select>
        </label>
      </div>
    </div>
  );
}

window.TYPES = TYPES;
window.TypeFilters = TypeFilters;
