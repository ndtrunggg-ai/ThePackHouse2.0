function Nav({ onCartOpen, cartCount = 0, onSearchChange, searchValue }) {
  return (
    <header className="tph-nav">
      <div className="tph-nav-inner">
        <a className="tph-wordmark" href="#">The Pack House</a>
        <nav className="tph-nav-links">
          <a className="tph-nav-link active">Shop</a>
          <a className="tph-nav-link">Brands</a>
          <a className="tph-nav-link">Travel Guides</a>
          <a className="tph-nav-link">Visit</a>
        </nav>
        <div className="tph-nav-search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
            <circle cx="11" cy="11" r="7" /><line x1="16.5" y1="16.5" x2="21" y2="21" />
          </svg>
          <input
            type="search"
            placeholder="Search Thule, carry-on, laptop sleeve…"
            value={searchValue}
            onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
            aria-label="Search products"
          />
        </div>
        <div className="tph-nav-right">
          <a className="tph-nav-link">Help</a>
          <button className="tph-icon-btn" onClick={onCartOpen} aria-label={`Cart (${cartCount} items)`}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
              <path d="M5 7h14l-1.5 11a2 2 0 0 1-2 1.7H8.5a2 2 0 0 1-2-1.7L5 7z" />
              <path d="M9 7V5a3 3 0 0 1 6 0v2" />
            </svg>
            {cartCount > 0 && <span className="tph-cart-dot">{cartCount}</span>}
          </button>
        </div>
      </div>
      <div className="tph-nav-band">
        <span className="tph-rule" />
        <span className="tph-eyebrow">EST. HANOI · MMXXV</span>
        <span className="tph-rule" />
        <span className="tph-eyebrow tph-eyebrow-soft">Free shipping over 2,000,000 ₫</span>
        <span className="tph-rule" />
        <span className="tph-eyebrow tph-eyebrow-soft">60-day return on unused gear</span>
        <span className="tph-rule" />
        <span className="tph-eyebrow tph-eyebrow-soft">Pay over 4 months with Atome</span>
        <span className="tph-rule" />
      </div>
    </header>
  );
}

window.Nav = Nav;
